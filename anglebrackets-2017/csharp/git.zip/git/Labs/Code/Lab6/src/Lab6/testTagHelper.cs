using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab6
{
  public class TestTagHelper : TagHelper
  {
    public string attr { get; set; } = "asdf";

    public async override Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
    {
      output.TagName = null;

      output.Content.AppendHtml(attr);

    }
  }
}