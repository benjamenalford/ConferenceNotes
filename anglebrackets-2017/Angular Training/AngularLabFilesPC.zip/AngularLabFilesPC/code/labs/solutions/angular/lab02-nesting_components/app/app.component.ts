import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: '<project-list></project-list>'
})
export class AppComponent{}