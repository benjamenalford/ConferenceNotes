(function () {
    function greeter(person) {
        return "Hello, " + person.firstName + " " + person.lastName;
    }
    var user = { firstName: "Anders", lastName: "Hejlsberg" };
    console.log(greeter(user));
})();
//# sourceMappingURL=03-interfaces.js.map