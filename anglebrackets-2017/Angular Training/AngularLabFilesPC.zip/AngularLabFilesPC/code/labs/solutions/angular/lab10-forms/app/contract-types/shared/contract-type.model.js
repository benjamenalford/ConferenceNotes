"use strict";
var ContractType = (function () {
    function ContractType(id, name) {
        this.id = id;
        this.name = name;
    }
    return ContractType;
}());
exports.ContractType = ContractType;
//# sourceMappingURL=contract-type.model.js.map