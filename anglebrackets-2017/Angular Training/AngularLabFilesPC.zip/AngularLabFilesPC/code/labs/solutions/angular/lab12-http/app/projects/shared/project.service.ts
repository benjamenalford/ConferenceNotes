import {Injectable, Optional} from "@angular/core";
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';

import {Project} from "./project.model";
import {Logger} from "../../shared/logger.service";

@Injectable()
export class ProjectService{
    private projectsUrl = "http://localhost:3000/projects/";

    constructor(private http: Http,@Optional() private logger: Logger){
        if(this.logger) {
            this.logger.log("In the project service constructor.");
        }
    }

    list(): Observable<Project[]>{
        return this.http.get(this.projectsUrl)
            .map(this.extractData)
            .catch(this.handleError);
    }

    put(project: Project){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });

        let url = `${this.projectsUrl}${project.id}`;
        let body = JSON.stringify(project);

        return this.http
            .put(url,body,options)
            .map(()=> project)
            .catch(this.handleError);
    }

    delete(project: Project){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        //IMPORTANT: the body needs to be set to empty string because of a bug in RC5
        //http://stackoverflow.com/questions/38896986/angular-2-rc-5-bootstrap-custom-http-class-typeerror-cannot-read-property-tost
        let options = new RequestOptions({ body: "", headers: headers });
        let url = `${this.projectsUrl}${project.id}`;

        return this.http
                .delete(url, options)
                .catch(this.handleError);
    }

    //observable
    private extractData(responseSerialized: Response){
        let response = responseSerialized.json();
        return response || {};
    }


    private handleError(error:any){
         let errorMessage = (error.message)? error.message:
             error.status ? `${error.status} - ${error.statusText}`: 'Server error';
        //TODO: log this error message

        return Observable.throw("An error occurred.  Please try the last operation again.");
    }

    //promise
    // list(): Promise<Project[]>{
    //     return this.http.get(this.projectsUrl)
    //         .toPromise()
    //         .then(this.extractDataReturnPromise)
    //         .catch(this.handleError);
    // }

    //promise
    // private extractDataReturnPromise(responseSerialized: Response){
    //     let response = responseSerialized.json();
    //     return Promise.resolve(response || {});
    // }
    //
    // //promise
    // private handleErrorReturnPromise(error:any){
    //
    //     return Promise.reject("An error occurred.  Please try the last operation again.");
    // }


}