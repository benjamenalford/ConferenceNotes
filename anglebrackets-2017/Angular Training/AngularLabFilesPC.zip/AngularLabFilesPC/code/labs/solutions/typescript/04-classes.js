(function () {
    var Student = (function () {
        function Student(firstName, middleInitial, lastName) {
            this.firstName = firstName;
            this.middleInitial = middleInitial;
            this.lastName = lastName;
        }
        Student.prototype.getFullName = function () {
            return this.firstName + " " +
                this.middleInitial + ". " +
                this.lastName;
        };
        return Student;
    }());
    var student = new Student("John", "D", "Rockefeller");
    console.log(student.getFullName());
})();
//# sourceMappingURL=04-classes.js.map