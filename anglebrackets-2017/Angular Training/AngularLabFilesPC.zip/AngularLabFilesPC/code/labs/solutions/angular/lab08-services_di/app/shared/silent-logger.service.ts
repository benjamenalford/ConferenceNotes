// An object in the shape of the logger service
let silentLogger = {
    logs: ['Silent logger says "Shhhhh!". Provided via "useValue"'],
    log: () => {}
};

export {silentLogger};
