// var name: string = 'Sean Carter';
// console.log(name);

// function hello(name: string){
//     return "hello " + name;
// }
//
// console.log(hello('Jeaves'));

// var age: number = 63;
// console.log(age);
//
// var isParent: boolean = true;
// console.log(isParent);

//any


