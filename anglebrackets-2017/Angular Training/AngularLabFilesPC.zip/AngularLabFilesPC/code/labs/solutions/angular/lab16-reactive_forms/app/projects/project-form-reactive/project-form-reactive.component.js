"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var project_model_1 = require('../shared/project.model');
var contract_type_service_1 = require("../../contract-types/shared/contract-type.service");
var forms_1 = require("@angular/forms");
var ProjectFormReactiveComponent = (function () {
    function ProjectFormReactiveComponent(formBuilder, contractTypeService) {
        this.formBuilder = formBuilder;
        this.contractTypeService = contractTypeService;
        this.save = new core_1.EventEmitter();
        this.cancel = new core_1.EventEmitter();
    }
    ProjectFormReactiveComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.contractTypeService.list()
            .then(function (contractTypes) { return _this.contractTypes = contractTypes; });
        this.projectForm = this.formBuilder.group({
            name: [this.project.name, [forms_1.Validators.required, forms_1.Validators.minLength(3)]],
            description: [this.project.description, forms_1.Validators.required],
            isActive: [this.project.isActive],
            contractTypeId: [this.project.contractTypeId]
        });
        this.name = this.projectForm.controls['name'];
        this.description = this.projectForm.controls["description"];
        this.isActive = this.projectForm.controls["isActive"];
        this.contractTypeId = this.projectForm.controls["contractTypeId"];
    };
    ProjectFormReactiveComponent.prototype.onSave = function (form) {
        console.log(form.value);
        console.log(this.name.errors);
        var updatedProject = Object.assign(this.project, form.value);
        this.save.emit(updatedProject);
    };
    ProjectFormReactiveComponent.prototype.onCancel = function (project, event) {
        event.preventDefault();
        this.cancel.emit(this.project);
    };
    ProjectFormReactiveComponent.prototype.hasErrors = function (control) {
        var hasNoErrors = (control.valid || control.pristine || !control.touched);
        return !hasNoErrors;
    };
    ProjectFormReactiveComponent.prototype.setErrorClass = function (control) {
        var hasErrors = this.hasErrors(control);
        return {
            "has-error": hasErrors
        };
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', project_model_1.Project)
    ], ProjectFormReactiveComponent.prototype, "project", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProjectFormReactiveComponent.prototype, "save", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProjectFormReactiveComponent.prototype, "cancel", void 0);
    ProjectFormReactiveComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'project-form-reactive',
            templateUrl: 'project-form-reactive.component.html',
            styles: [".btn-cancel{\n            margin-left:15px;\n            }"],
            providers: [contract_type_service_1.default]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, contract_type_service_1.default])
    ], ProjectFormReactiveComponent);
    return ProjectFormReactiveComponent;
}());
exports.ProjectFormReactiveComponent = ProjectFormReactiveComponent;
//# sourceMappingURL=project-form-reactive.component.js.map