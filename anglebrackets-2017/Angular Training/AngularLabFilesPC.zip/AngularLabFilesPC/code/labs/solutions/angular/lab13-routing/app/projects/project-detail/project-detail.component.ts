import { Component,
        OnInit,
        OnDestroy } from '@angular/core';
import { Project } from "../shared/project.model";
import { ProjectService } from "../shared/project.service";


import { ActivatedRoute, Router} from '@angular/router';

@Component({
    moduleId : module.id,
    selector: 'project-detail',
    templateUrl: 'project-detail.component.html',
})
export class ProjectDetailComponent implements OnInit, OnDestroy{
    project: Project;
    errorMessage: string;
    subscription: any;
    paramsSubscription: any;

    constructor(private projectService: ProjectService,
                private route: ActivatedRoute,
                private router: Router){}

    ngOnInit(){
        this.getProject();
    }

    getProject(){

        //snapshot
        // let id = this.route.snapshot.params['id'];
        //
        // this.subscription = this.projectService
        //     .find(id)
        //     .subscribe((p)=>this.project = p,
        //         (e)=> this.errorMessage = e);


        this.paramsSubscription = this.route.params.subscribe(params => {
            if (params['id'] !== undefined) {
                let id = +params['id'];
                this.subscription = this.projectService
                    .find(id)
                    .subscribe((p)=>this.project = p,
                        (e)=> this.errorMessage = e);
            }
        });

    }

    ngOnDestroy(){
        this.subscription.unsubscribe();
        this.paramsSubscription.unsubscribe();
    }

    onNext(id: number){
           let link = ['/projects', id + 1, {testParam: 'test'}];
           this.router.navigate(link);
    }

}


