import {Component, Input, Output, EventEmitter, OnInit} from '@angular/core';

import { Project } from '../shared/project.model';
import ContractTypeService from "../../contract-types/shared/contract-type.service";
import {ContractType} from "../../contract-types/shared/contract-type.model";
import {FormBuilder, FormGroup, AbstractControl, Validators} from "@angular/forms";

@Component({
    moduleId: module.id,
    selector: 'project-form-reactive',
    templateUrl: 'project-form-reactive.component.html',
    styles: [`.btn-cancel{
            margin-left:15px;
            }`],
    providers: [ContractTypeService]
})
export class ProjectFormReactiveComponent implements OnInit{
    @Input() project: Project;
    @Output() save = new EventEmitter<Project>();
    @Output() cancel = new EventEmitter<Project>();
    projectForm : FormGroup;
    name : AbstractControl;
    description: AbstractControl;
    isActive:  AbstractControl;
    contractTypeId: AbstractControl;

    contractTypes: ContractType [];

    constructor(private formBuilder: FormBuilder,private contractTypeService: ContractTypeService){}

    ngOnInit(): void {

        this.contractTypeService.list()
            .then(contractTypes=> this.contractTypes = contractTypes);

        this.projectForm = this.formBuilder.group({
            name : [this.project.name, [Validators.required, Validators.minLength(3)]],
            description : [this.project.description, Validators.required],
            isActive: [this.project.isActive],
            contractTypeId: [this.project.contractTypeId]
        });

        this.name = this.projectForm.controls['name'];
        this.description = this.projectForm.controls["description"];
        this.isActive = this.projectForm.controls["isActive"];
        this.contractTypeId = this.projectForm.controls["contractTypeId"];

    }

    onSave(form){
        console.log(form.value);
        console.log(this.name.errors);
        
        let updatedProject = Object.assign(this.project, form.value);
        this.save.emit(updatedProject);
    }

    onCancel(project, event){
        event.preventDefault();
        this.cancel.emit(this.project);
    }

    hasErrors(control: AbstractControl){
        let hasNoErrors = (control.valid || control.pristine || !control.touched);
        return !hasNoErrors;
    }

    setErrorClass(control:AbstractControl){
        var hasErrors = this.hasErrors(control);
        return {
            "has-error": hasErrors
        }
    }

    // hideError(control: AbstractControl, validationType){
    //     if(!modelDirective.errors){return true;}
    //     return !modelDirective.errors[validationType];
    // }

    // hideErrors(modelDirective){
    //     return (modelDirective.valid || modelDirective.pristine || !modelDirective.touched);
    // }
    //
    // hideError(modelDirective, validationType){
    //     if(!modelDirective.errors){return true;}
    //     return !modelDirective.errors[validationType];
    // }

    // setErrorClass(modelDirective){
    //     var hideError = this.hideErrors(modelDirective);
    //     return {
    //         "has-error": !hideError
    //     }
    // }



}