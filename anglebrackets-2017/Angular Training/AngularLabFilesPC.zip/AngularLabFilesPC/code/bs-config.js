module.exports = {
  server: true,
  "port": 4000
};