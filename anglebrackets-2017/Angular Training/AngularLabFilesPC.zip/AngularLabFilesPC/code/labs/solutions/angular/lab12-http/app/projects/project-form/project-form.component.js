"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var project_model_1 = require('../shared/project.model');
var contract_type_service_1 = require("../../contract-types/shared/contract-type.service");
var ProjectFormComponent = (function () {
    function ProjectFormComponent(contractTypeService) {
        this.contractTypeService = contractTypeService;
        this.save = new core_1.EventEmitter();
        this.cancel = new core_1.EventEmitter();
    }
    ProjectFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.contractTypeService.list()
            .then(function (contractTypes) { return _this.contractTypes = contractTypes; });
    };
    ProjectFormComponent.prototype.onSave = function (form) {
        var updatedProject = Object.assign(this.project, form.value.project);
        this.save.emit(updatedProject);
    };
    ProjectFormComponent.prototype.onCancel = function (project, event) {
        event.preventDefault();
        this.cancel.emit(this.project);
    };
    ProjectFormComponent.prototype.hideErrors = function (modelDirective) {
        return (modelDirective.valid || modelDirective.pristine || !modelDirective.touched);
    };
    ProjectFormComponent.prototype.hideError = function (modelDirective, validationType) {
        if (!modelDirective.errors) {
            return true;
        }
        return !modelDirective.errors[validationType];
    };
    ProjectFormComponent.prototype.setErrorClass = function (modelDirective) {
        var hideError = this.hideErrors(modelDirective);
        return {
            "has-error": !hideError
        };
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', project_model_1.Project)
    ], ProjectFormComponent.prototype, "project", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProjectFormComponent.prototype, "save", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProjectFormComponent.prototype, "cancel", void 0);
    ProjectFormComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'project-form',
            templateUrl: 'project-form.component.html',
            styles: [".btn-cancel{\n            margin-left:15px;\n            }"],
            providers: [contract_type_service_1.default]
        }), 
        __metadata('design:paramtypes', [contract_type_service_1.default])
    ], ProjectFormComponent);
    return ProjectFormComponent;
}());
exports.ProjectFormComponent = ProjectFormComponent;
//# sourceMappingURL=project-form.component.js.map