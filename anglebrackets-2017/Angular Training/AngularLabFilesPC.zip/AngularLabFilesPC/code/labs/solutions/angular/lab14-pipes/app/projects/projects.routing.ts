import {Routes, RouterModule} from "@angular/router";

import {ProjectListComponent} from "./project-list/project-list.component";
import {ProjectDetailComponent} from "./project-detail/project-detail.component";
import {ModuleWithProviders} from "@angular/core";

const projectRoutes: Routes = [
    {path: 'projects', component: ProjectListComponent},
    {path: 'projects/:id', component: ProjectDetailComponent}
]

export const projectsRoutingModule: ModuleWithProviders = RouterModule.forChild(projectRoutes);
