import { Component } from '@angular/core';

@Component({
    selector: 'project-list',
    template: '<h1>Projects</h1>'
})
export class ProjectListComponent{}