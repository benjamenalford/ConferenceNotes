"use strict";
//program.ts
var _08_my_module_1 = require("./08-my-module");
console.log(_08_my_module_1.myFunction());
console.log(_08_my_module_1.myObject.name);
console.log(_08_my_module_1.myObject.myMethod());
console.log(_08_my_module_1.myPrimitive);
var myClass = new _08_my_module_1.MyClass();
console.log(myClass.myClassMethod());
//if MyClass is made the default we could use this syntax
//import MyClass from "./09-my-module";
//# sourceMappingURL=08-modules.js.map