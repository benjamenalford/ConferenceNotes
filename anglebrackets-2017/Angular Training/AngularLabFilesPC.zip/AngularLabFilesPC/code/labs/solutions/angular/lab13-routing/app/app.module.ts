import { NgModule }       from '@angular/core';
import { BrowserModule  } from '@angular/platform-browser';
import { HttpModule} from '@angular/http';

import { appRoutingModule} from "./app.routing";
import { AppComponent }   from './app.component';
import {Logger} from "./shared/logger.service";
import { HomeComponent } from "./home/home.component";

@NgModule({
    declarations: [AppComponent, HomeComponent],
    imports:      [BrowserModule, HttpModule, appRoutingModule],
    bootstrap:    [AppComponent],
    providers: [Logger]
})
export class AppModule {}


//Step 1
// import {ProjectListComponent} from './projects/project-list/project-list.component';
// import {ProjectCardComponent} from './projects/project-card/project-card.component';
// import {ProjectFormComponent} from './projects/project-form/project-form.component';
// import {ProjectService} from "./projects/shared/project.service";
// import {appRoutingModule, appRoutingProviders} from "./app.routing";
// import {FormsModule} from "@angular/forms";
//
// @NgModule({
//     declarations: [AppComponent, HomeComponent,
//                     ProjectListComponent, ProjectCardComponent,
//                     ProjectFormComponent],
//         imports: [BrowserModule, FormsModule,
//                     HttpModule, appRoutingModule],
//         bootstrap: [AppComponent],
//         providers: [ProjectService, Logger]
// })
// export class AppModule {}
