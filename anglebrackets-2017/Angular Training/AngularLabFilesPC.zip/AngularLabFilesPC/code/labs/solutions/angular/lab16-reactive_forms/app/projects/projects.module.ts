import { NgModule }       from '@angular/core';
import {CommonModule} from '@angular/common';
import {ReactiveFormsModule}   from '@angular/forms';

import { ProjectListComponent } from './project-list/project-list.component';
import { ProjectCardComponent } from './project-card/project-card.component';
//import { ProjectFormComponent } from './project-form/project-form.component';
import {ProjectFormReactiveComponent} from "./project-form-reactive/project-form-reactive.component";
import { ProjectService } from "./shared/project.service";
import {projectsRoutingModule} from "./projects.routing";
import {ProjectDetailComponent} from "./project-detail/project-detail.component";
import {CharacterLengthPipe} from "../shared/pipes/character-length.pipe";
import {ConfirmDirective} from "../shared/confirm.directive";
import {ConfirmDialogComponent} from "../shared/confirm-dialog/confirm-dialog.component";


@NgModule({
    declarations: [ProjectListComponent,
                   ProjectCardComponent,
                   ProjectFormReactiveComponent,
                   ProjectDetailComponent,
                   ConfirmDirective,
                   ConfirmDialogComponent],
    imports:      [CommonModule,
                   ReactiveFormsModule,
                   projectsRoutingModule],
    providers: [ProjectService, CharacterLengthPipe]
})
export class ProjectsModule {}