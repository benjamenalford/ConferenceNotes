import {Component} from '@angular/core';

@Component({
    selector: 'my-home',
    template: `<h3>Home</h3>`

})
export class HomeComponent{}
