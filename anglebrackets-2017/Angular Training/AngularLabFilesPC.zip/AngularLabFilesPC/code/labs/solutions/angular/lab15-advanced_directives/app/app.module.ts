import { NgModule }       from '@angular/core';
import { BrowserModule  } from '@angular/platform-browser';
import { HttpModule} from '@angular/http';

import { appRoutingModule} from "./app.routing";
import { AppComponent }   from './app.component';
import {Logger} from "./shared/logger.service";
import { HomeComponent } from "./home/home.component";

import {ProjectsModule} from "./projects/projects.module";
import {TabsModule} from "./tabs/tabs.module";

@NgModule({
    declarations: [AppComponent, HomeComponent],
    imports:      [BrowserModule, HttpModule, appRoutingModule, ProjectsModule, TabsModule],
    bootstrap:    [AppComponent],
    providers: [Logger]
})
export class AppModule {}

