﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp7Demo
{
    public class Spring2016TermMessaging
    {
        public (IEnumerable<string> messages, int staffCount, int) GetThankYouMessages(IEnumerable<Person> persons)
        {
            var messages = new List<string>();
            var staffCount = 0;
            foreach (var person in persons)
            {
                var message = GetThankYouMessage(person);

                var staff = person as Staff;
                if (staff != null)
                { staffCount += 1; }

                messages.Add(message);
            }
            return (messages, staffCount, 42);
        }

        private string GetThankYouMessage(Person person)
        {
            switch (person)
            {
                case Student student when (student.GPA > 3.2m):
                    return $"Thanks {student.Name} for being  an honor student " +
                        $"this term, sorry about the flood";
                case Student student:
                    return "Thanks for being a student this term, sorry about the flood";
                case Instructor instructor:
                    return $"Thanks for teaching {string.Join(", ", instructor.Courses)}";
                case Staff staff:
                    return $"Thanks for being a {staff.StaffRole.ToString()}";
                default:
                    throw new InvalidOperationException();
            }
        }
    }
