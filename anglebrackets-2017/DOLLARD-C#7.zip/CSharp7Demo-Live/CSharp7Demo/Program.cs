﻿using System;
using System.Collections.Generic;

namespace CSharp7Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            IDictionary<int, Person> persons = GetData();
            var term = new Spring2016TermMessaging();
            var (messages, staffCount, meaningOfLife) = term.GetThankYouMessages(
                    persons.Values);

            Console.WriteLine("Staff count: {0}", staffCount );
            Console.Write(string.Join("\n", messages));
            Console.Read();
        }

        private static IDictionary<Int32, Person> GetData()
        {
            ISeedData<Person> seedData = new SeedDataForPerson();
            return seedData.GetData();
        }

        private static Person GetPerson(
                        IDictionary<int, Person> persons, int id)
        {
            return persons[id];
        }
    }
}
