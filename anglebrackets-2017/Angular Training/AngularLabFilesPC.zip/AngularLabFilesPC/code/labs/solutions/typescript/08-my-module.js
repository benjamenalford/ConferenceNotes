"use strict";
//my-module.ts
function myFunction() {
    return "myFunction was run.";
}
exports.myFunction = myFunction;
var myObject = {
    name: 'I can access myObject\'s name',
    myMethod: function () { return 'myMethod on myObject is running.'; }
};
exports.myObject = myObject;
exports.myPrimitive = 55;
var MyClass = (function () {
    function MyClass() {
    }
    MyClass.prototype.myClassMethod = function () {
        return "myClassMethod on myClass is running.";
    };
    return MyClass;
}());
exports.MyClass = MyClass;
//# sourceMappingURL=08-my-module.js.map