"use strict";
// An object in the shape of the logger service
var silentLogger = {
    logs: ['Silent logger says "Shhhhh!". Provided via "useValue"'],
    log: function () { }
};
exports.silentLogger = silentLogger;
//# sourceMappingURL=silent-logger.service.js.map