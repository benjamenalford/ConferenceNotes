import { Component, OnInit, Input } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'tab',
    template: `
    <div [hidden]="!active" class="tab-pane">
      <ng-content></ng-content>
    </div>
  `
})
export class TabComponent {
    @Input() title: string;
    @Input() active: boolean = false;
}