(function () {
    var Student = (function () {
        function Student(firstName, middleInitial, lastName) {
            this.firstName = firstName;
            this.middleInitial = middleInitial;
            this.lastName = lastName;
        }
        return Student;
    }());
    function greeter(person) {
        return "Hello, " + person.firstName + " " + person.lastName;
    }
    var student = new Student("John", "D", "Rockefeller");
    console.log(greeter(student));
})();
//# sourceMappingURL=09-classes-interfaces.js.map