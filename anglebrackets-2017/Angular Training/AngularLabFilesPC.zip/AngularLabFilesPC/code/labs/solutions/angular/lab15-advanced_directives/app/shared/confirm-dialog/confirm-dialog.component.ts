import {Component, OnInit, EventEmitter, Input, Output} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'confirm-dialog',
    templateUrl: 'confirm-dialog.component.html'
})
export class ConfirmDialogComponent{
    @Output() confirm = new EventEmitter();
    @Output() cancel = new EventEmitter();

    onConfirm(){
        this.confirm.emit();
        this.close();
    }

    onCancel(){
        this.cancel.emit();
        this.close();
    }

    @Input() message : string;
    hidden: boolean = true;

    open(){
        this.hidden = false;
    }

    close(){
        this.hidden = true;
    }
}

