"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var project_model_1 = require('../shared/project.model');
var ProjectCardComponent = (function () {
    function ProjectCardComponent() {
        this.edit = new core_1.EventEmitter();
        this.actionDropdownIsOpen = false;
    }
    ProjectCardComponent.prototype.getDropdownCssClasses = function () {
        return {
            dropdown: true,
            open: this.actionDropdownIsOpen
        };
    };
    ProjectCardComponent.prototype.toggleActions = function () {
        this.actionDropdownIsOpen = !this.actionDropdownIsOpen;
    };
    ProjectCardComponent.prototype.onEdit = function (project, event) {
        event.preventDefault();
        this.edit.emit(project);
    };
    ProjectCardComponent.prototype.ngOnInit = function () { };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', project_model_1.Project)
    ], ProjectCardComponent.prototype, "project", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProjectCardComponent.prototype, "edit", void 0);
    ProjectCardComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'project-card',
            templateUrl: 'project-card.component.html',
            // styles: [`h4{
            //             color:#9c27b0;
            //           }`],
            styleUrls: ['project-card.component.css'],
            encapsulation: core_1.ViewEncapsulation.Emulated
        }), 
        __metadata('design:paramtypes', [])
    ], ProjectCardComponent);
    return ProjectCardComponent;
}());
exports.ProjectCardComponent = ProjectCardComponent;
//# sourceMappingURL=project-card.component.js.map