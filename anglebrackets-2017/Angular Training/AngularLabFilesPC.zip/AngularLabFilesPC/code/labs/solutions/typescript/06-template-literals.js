(function () {
    var Student = (function () {
        function Student(firstName, middleInitial, lastName) {
            this.firstName = firstName;
            this.middleInitial = middleInitial;
            this.lastName = lastName;
        }
        Student.prototype.getFullName = function () {
            return this.firstName + " " + this.middleInitial + ". " + this.lastName;
        };
        return Student;
    }());
    var student = new Student("John", "D", "Rockefeller");
    console.log(student.getFullName());
    var html = "<div class=\"container\">\n                    <div class=\"row\">\n                        <p>\n                        Here is some text that \n                        I want to show on a page.\n                        </p>\n                    </div>\n                </div>";
    console.log(html);
})();
//# sourceMappingURL=06-template-literals.js.map