(function () {

    function greeter(name){
        return "Hi: " + name;
    }

    console.log(greeter("Anders"));

})();



