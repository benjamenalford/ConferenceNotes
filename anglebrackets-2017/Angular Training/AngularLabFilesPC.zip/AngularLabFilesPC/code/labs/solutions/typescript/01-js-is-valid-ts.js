(function () {
    function greeter(name) {
        return "Hi: " + name;
    }
    console.log(greeter("Anders"));
})();
//# sourceMappingURL=01-js-is-valid-ts.js.map